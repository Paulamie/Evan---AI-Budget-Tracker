from flask import Flask, request, session, render_template, url_for, jsonify, redirect
from passlib.hash import sha256_crypt
import hashlib
import gc
from functools import wraps
import dbfunc, mysql.connector 
from datetime import datetime

app = Flask (__name__) #instantiating flask app
app.secret_key = 'Super Secret' #secret key for sessions 

#booking process:
#home page 
@app.route('/') #decorator/ endpoints
@app.route('/home/')
def homePage():
    conn = dbfunc.getConnection()
    if conn != None:    #Checking if connection is None         
        print('MySQL Connection is established')                          
        dbcursor = conn.cursor()    #Creating cursor object            
        dbcursor.execute('SELECT DISTINCT deptCity FROM routes;') #booking process starts here         
        rows = dbcursor.fetchall()                                    
        dbcursor.close()              
        conn.close() #Connection must be 
        cities = []
        for city in rows:
            city = str(city).strip("(")
            city = str(city).strip(")")
            city = str(city).strip(",")
            city = str(city).strip("'")
            cities.append(city)
    return render_template('home1.html', departurelist=cities)

@app.route ('/returncity/', methods = ['POST', 'GET'])
def ajax_returncity():   
	print('/returncity') 

	if request.method == 'GET':
		deptcity = request.args.get('q')
		conn = dbfunc.getConnection()
		if conn != None:    #Checking if connection is None                               
			dbcursor = conn.cursor()    #Creating cursor object            
			dbcursor.execute('SELECT DISTINCT arrivCity FROM routes WHERE deptCity = %s;', (deptcity,)) #gives the return options from the selected city              
			rows = dbcursor.fetchall()
			total = dbcursor.rowcount                                    
			dbcursor.close()              
			conn.close() #Connection must be closed			
			return jsonify(returncities=rows, size=total)
		else:
			print('DB connection Error')
			return jsonify(returncities='DB Connection Error') 

#display prices from the selected route 
@app.route ('/prices/', methods = ['POST', 'GET']) 
def selectBooking():
    if request.method == 'POST':
        departcity = request.form['departureslist']
        arrivalcity = request.form['arrivalslist']
        arrivalcity = request.form['arrivalslist']
        outdate = request.form['outdate']
        returndate = request.form['returndate']
        adultseats = request.form['adultseats']
        childseats = request.form['childseats']
        journeytype = request.form ['journeytype']
        lookupdata = [departcity, arrivalcity, outdate, returndate, adultseats, childseats, journeytype]
        conn = dbfunc.getConnection()
        if conn != None:    #Checking if connection is None        
            print('MySQL Connection is established')                          
            dbcursor = conn.cursor()    #Creating cursor object            
            dbcursor.execute('SELECT * FROM routes WHERE deptCity = %s AND arrivCity = %s;', (departcity, arrivalcity))           
            rows = dbcursor.fetchall()
            datarows=[]			
            for row in rows:
                data = list(row)                    
                fare = (float(row[5]) * float(adultseats)) + (float(row[5]) * 0.5 * float(childseats))
                data.append(fare)
                datarows.append(data)			
            dbcursor.close()              
            conn.close() #Connection must be closed	
            return render_template('showPrices.html', resultset=datarows, lookupdata=lookupdata) 
    else: 
        print("something went wrong")
        return render_template ("NoPrice.html")

#display the receipt for the journey selected 
@app.route ('/booking_confirm/', methods = ['POST', 'GET']) 
def booking_confirm():
	if request.method == 'POST':		
		print('booking confirm initiated')
		journeyid = request.form['bookingchoice']		
		departcity = request.form['deptcity']
		arrivalcity = request.form['arrivcity']
		outdate = request.form['outdate']
		returndate = request.form['returndate']
		adultseats = request.form['adultseats']
		childseats = request.form['childseats']
		totalfare = request.form['totalfare']
		cardnumber = request.form['cardnumber']
		journeytype = request.form ['journeytype']
  

		totalseats = int(adultseats) + int(childseats)
		bookingdata = [journeyid, departcity, arrivalcity, outdate, returndate, adultseats, childseats, totalfare, journeytype]
		print(bookingdata)
		conn = dbfunc.getConnection()
		if conn != None:    #Checking if connection is None         
			print('MySQL Connection is established')                          
			dbcursor = conn.cursor()    #Creating cursor object     	
			dbcursor.execute('INSERT INTO bookings (deptDate, arrivDate, idRoutes, noOfSeats, totFare) VALUES \
				(%s, %s, %s, %s, %s);', (outdate, returndate, journeyid, totalseats, totalfare))   
			print('Booking statement executed successfully.')             
			conn.commit()	
			#dbcursor.execute('SELECT AUTO_INCREMENT - 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s;', ('TEST_DB', 'bookings'))   
			dbcursor.execute('SELECT LAST_INSERT_ID();')
			#print('SELECT statement executed successfully.')             
			rows = dbcursor.fetchone()
			#print ('row count: ' + str(dbcursor.rowcount))
			bookingid = rows[0]
			bookingdata.append(bookingid)
			dbcursor.execute('SELECT * FROM routes WHERE idRoutes = %s;', (journeyid,))   			
			rows = dbcursor.fetchall()
			deptTime = rows[0][2]
			arrivTime = rows[0][4]
			bookingdata.append(deptTime)
			bookingdata.append(arrivTime)
			#print(bookingdata)
			#print(len(bookingdata))
			cardnumber = cardnumber[-4:-1]
			print(cardnumber)
			dbcursor.execute
			dbcursor.close()              
			conn.close() #Connection must be closed
			return render_template('booking_confirm.html', resultset=bookingdata, cardnumber=cardnumber)
		else:
			print('DB connection Error')
			return redirect(url_for('index')) 

@app.route ('/dumpsVar/', methods = ['POST', 'GET']) #i'm not sure we need this 
def dumpVar():
	if request.method == 'POST':
		result = request.form
		output = "<H2>Data Received: </H2></br>"
		output += "Number of Data Fields : " + str(len(result))
		for key in list(result.keys()):
			output = output + " </br> " + key + " : " + result.get(key)
		return output
	else:
		result = request.args
		output = "<H2>Data Received: </H2></br>"
		output += "Number of Data Fields : " + str(len(result))
		for key in list(result.keys()):
			output = output + " </br> " + key + " : " + result.get(key)
		return output  

#starting the log in process hopefully

#here the user should be prompted to sign up/ log in - this is before they get their receipt 

@app.route('/home/<usertype>') #display contents depending on if user is admin or standard 
def homepage(usertype):
    return render_template ('account2.html', usertype=usertype)

# My account page
@app.route ('/myAccount/') #inherirance:base.html
def myAccount():
    return render_template ('account2.html') 

@app.route('/register/', methods=['POST', 'GET'])
def register():
    error = ''
    print('Register start')
    try:
        if request.method == "POST":         
            username = request.form['username']
            password = request.form['password']
            email = request.form['email']                      
            if username != None and password != None and email != None:           
                conn = dbfunc.getConnection()
                if conn != None:    #Checking if connection is None           
                    if conn.is_connected(): #Checking if connection is established
                        print('MySQL Connection is established')                          
                        dbcursor = conn.cursor()    #Creating cursor object 
                        #here we should check if username / email already exists                                                           
                        password = sha256_crypt.hash((str(password)))           
                        Verify_Query = "SELECT * FROM users WHERE username = %s;"
                        dbcursor.execute(Verify_Query,(username,))
                        rows = dbcursor.fetchall()           
                        if dbcursor.rowcount > 0:   #this means there is a user with same name
                            print('username already taken, please choose another')
                            error = "User name already taken, please choose another"
                            return render_template("account2.html", error=error)    
                        else:   #this means we can add new user             
                            dbcursor.execute("INSERT INTO users (username, password_hash, \
                                 email) VALUES (%s, %s, %s)", (username, password, email))                
                            conn.commit()  #saves data in database              
                            print("Thanks for registering!")
                            dbcursor.close()
                            conn.close()
                            gc.collect()                        
                            session['logged_in'] = True     #session variables
                            session['username'] = username
                            session['usertype'] = 'standard'   #default all users are standard
                            return render_template("success.html",\
                             message='User registered successfully and logged in..')
                    else:                        
                        print('Connection error')
                        return 'DB Connection Error'
                else:                    
                    print('Connection error')
                    return 'DB Connection Error'
            else:                
                print('empty parameters')
                return render_template("account2.html", error=error)
        else:            
            return render_template("account2.html", error=error)        
    except Exception as e:                
        return render_template("account2.html", error=e)    
    return render_template("account2.html", error=error)


#/login/ route receives user name and password and checks against db user/pw
@app.route('/login/', methods=["GET","POST"])
def login():
    form={}
    error = ''
    try:	
        if request.method == "POST":            
            username = request.form['username']
            password = request.form['password']            
            form = request.form
            print('login start 1.1')
            
            if username != None and password != None:  #check if un or pw is none          
                conn = dbfunc.getConnection()
                if conn != None:    #Checking if connection is None                    
                    if conn.is_connected(): #Checking if connection is established                        
                        print('MySQL Connection is established')                          
                        dbcursor = conn.cursor()    #Creating cursor object                                                 
                        dbcursor.execute("SELECT password_hash, usertype \
                            FROM users WHERE username = %s;", (username,))                                                
                        data = dbcursor.fetchone()
                        print(data[0])
                        if dbcursor.rowcount < 1: #this mean no user exists                         
                            error = "User / password does not exist, login again"
                            return render_template("account2.html", error=error)
                        else:                            
                            #data = dbcursor.fetchone()[0] #extracting password   
                            # verify passowrd hash and password received from user                                                             
                            if sha256_crypt.verify(request.form['password'], str(data[0])): #having problems with this bit, it says that the Sha. Invalid credentials                               
                                session['logged_in'] = True     #set session variables
                                session['username'] = request.form['username']
                                session['usertype'] = str(data[1])                          
                                print("You are now logged in")                                
                                return render_template('userresources.html', \
                                    username=username, data='this is user specific data',\
                                         usertype=session['usertype'])
                            else:
                                error = "Invalid credentials username/password, try again."                               
                    gc.collect()
                    print('login start 1.10')
                    return render_template("account2.html", form=form, error=error)
    except Exception as e:                
        error = str(e) + " <br/> Invalid credentials, try again."
        return render_template("account2.html", form=form, error = error)   
    
    return render_template("account2.html", form=form, error = error)

def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:            
            print("You need to login first")
            #return redirect(url_for('login', error='You need to login first'))
            return render_template('account2.html', error='You need to login/ register first')    
    return wrap

def admin_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if ('logged_in' in session) and (session['usertype'] == 'admin'):
            return f(*args, **kwargs)
        else:            
            print("You need to login first as admin user")
            #return redirect(url_for('login', error='You need to login first as admin user'))
            return render_template('account2.html', error='You need to login first as admin user')    
    return wrap

def standard_user_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if ('logged_in' in session) and (session['usertype'] == 'standard'):
            return f(*args, **kwargs)
        else:            
            print("You need to login first as standard user")
            #return redirect(url_for('login', error='You need to login first as standard user'))
            return render_template('account2.html', error='You need to login first as standard user')    
    return wrap

#/logout is to log out of the system.
@app.route("/logout/")
@login_required
def logout():    
    session.clear()    #clears session variables
    print("You have been logged out!")
    gc.collect()
    return render_template('home1.html', optionalmessage='You have been logged out')

#/userfeatures is loaded for standard users
@app.route('/userfeatures/')
@login_required
@standard_user_required
def user_features():
        print('fetchrecords')
        #records from database can be derived
        #user login can be checked..
        print ('Welcome ', session['username'])
        return render_template('standarduser.html', \
            user=session['username'], message='User data from app and standard \
                user features can go here....')

#/adminfeatures is loaded for admin users
@app.route('/adminfeatures/')
@login_required
@admin_required
def admin_features():
        print('create / amend records / delete records / generate reports')
        #records from database can be derived, updated, added, deleted
        #user login can be checked..
        print ('Welcome ', session['username'], ' as ', session['usertype'])
        return render_template('adminuser.html', user=session['username'],\
             message='Admin data from app and admin features can go here ...')

#/generateadminreport is loaded for admin users only
@app.route('/generateadminreport/')
@login_required
@admin_required
def generate_admin_report():
    print('admin reports')
    #here you can generate required data as per business logic
    return """
        <h1> this is admin report for {} </h1>
        <a href='/adminfeatures')> Go to Admin Features page </a>
    """.format(session['username'])
#updates the password for the Admins
@app.route('/updatePassword')
@login_required
@admin_required
def update_admin_password():
    error = ''
    print('update start')
    try:
        if request.method == "POST": #can't get inside tbis function for some reason
            print('test1')
            id = request.form['id']        
            password = request.form['password']                 
            if  password != None: 
                print ('test2')          
                conn = dbfunc.getConnection()
                if conn != None:    #Checking if connection is None           
                    if conn.is_connected(): #Checking if connection is established
                        print('MySQL Connection is established')                          
                        dbcursor = conn.cursor()    #Creating cursor object 
                        #here we should check if username / email already exists                                                           
                        password = sha256_crypt.hash((str(password)))           
                        Verify_Query = "SELECT * FROM users WHERE username = %s;"
                        dbcursor.execute(Verify_Query,(password,))
                        rows = dbcursor.fetchall()           
                        if dbcursor.rowcount > 0:   #this means there is a user wants to set the password that they're already using
                            print('password has to be different from your current passsword')
                            error = "Your new password has to be different from your current password"
                            return render_template("changepassword.html", error=error)    
                        else:   #this means we can add new user             
                            dbcursor.execute("UPDATE users SET (password_hash, \) VALUES WHERE userid = %s (%s, %s)", (password, id))                
                            conn.commit()  #saves data in database              
                            print("Thanks for updating your password!")
                            dbcursor.close()
                            conn.close()
                            gc.collect()                        
                            return render_template("successchange.html",\
                             message='Password updated successfully')
                    else:                        
                        print('Connection error')
                        return 'DB Connection Error'
                else:                    
                    print('Connection error')
                    return 'DB Connection Error'
            else:                
                print('empty parameters')
                return render_template("changepassword.html", error=error)
        else:            
            return render_template("changepassword.html", error=error)        
    except Exception as e:                
        return render_template("changepassword.html", error=e) 

#/generateuserrecord is loaded for standard users only
@app.route('/generateuserrecord/')
@login_required
@standard_user_required
def generate_user_record():
    print('User records')
    #here you can generate required data as per business logic
    return """
        <h1> this is User record for user {} </h1> 
        <a href='/userfeatures')> Go to User Features page </a>
    """.format(session['username']) #how can i make the history of a user booking be displayed here?
    #initial thought: during booking process user is required to log in and then we put the system to save that booing under the 
    
    #clients records. in here you pull out the booking that is under this user's ID.
    
#cancel booking. prompt user to enter bookings ID and then tell teh database to delete that booking 
    
#update user data -> all in one page write new name, email, password and then tell the database to update details.
@app.route('/updateInfo')
@login_required
@standard_user_required
def update_user_data():
    error = ''
    print('update start')
    try:
        if request.method == "POST": #can't get inside this function
            print('test1')
            id = request.form['id']        
            username = request.form['username']
            password = request.form['password']
            email = request.form['email']                      
            if username != None and password != None and email != None: 
                print ('test2')          
                conn = dbfunc.getConnection()
                if conn != None:    #Checking if connection is None           
                    if conn.is_connected(): #Checking if connection is established
                        print('MySQL Connection is established')                          
                        dbcursor = conn.cursor()    #Creating cursor object 
                        #here we should check if username / email already exists                                                           
                        password = sha256_crypt.hash((str(password)))           
                        Verify_Query = "SELECT * FROM users WHERE username = %s;"
                        dbcursor.execute(Verify_Query,(username,))
                        rows = dbcursor.fetchall()           
                        if dbcursor.rowcount > 0:   #this means there is a user with same name
                            print('username already taken, please choose another')
                            error = "User name already taken, please choose another"
                            return render_template("update.html", error=error)    
                        else:   #this means we can add new user             
                            dbcursor.execute("UPDATE users SET (username, password_hash, \
                                 email) VALUES WHERE userid = %s (%s, %s, %s, %s)", (username, password, email, id))                
                            conn.commit()  #saves data in database              
                            print("Thanks for updating your details!")
                            dbcursor.close()
                            conn.close()
                            gc.collect()                        
                            session['logged_in'] = True     #session variables
                            session['username'] = username
                            session['usertype'] = 'standard'   #default all users are standard
                            return render_template("successupdate.html",\
                             message='User updated successfully')
                    else:                        
                        print('Connection error')
                        return 'DB Connection Error'
                else:                    
                    print('Connection error')
                    return 'DB Connection Error'
            else:                
                print('empty parameters')
                return render_template("update.html", error=error)
        else:            
            return render_template("update.html", error=error)        
    except Exception as e:                
        return render_template("update.html", error=e)  


#privacy page 
@app.route ('/privacyStatement') #inheritance: base.html
def privacyPage():
    return render_template ('privacy4.html')

#cookies page 
@app.route ('/cookies') #inheritance: base.html
def Cookies():
    return render_template ('cookies3.html')

#view bookings page 
@app.route ('/viewBookings') #inheritance: secondbase.html
def viewBookings():
    return render_template ('viewBookings.html') 

#New booking page 
@app.route ('/bookings') #inheritance: secondbase.html
def newBookings():
    return render_template ('NewBookings.html') 



#debuggers
if __name__ == '__main__':   
   app.run(port=8000,debug = True)
   
if __name__ == '__main__':    #you can skip this if running app on terminal window
    for i in range(13000, 18000):
      try:
         app.run(debug = True, port = i)
         break
      except OSError as e:
         print("Port {i} not available".format(i))