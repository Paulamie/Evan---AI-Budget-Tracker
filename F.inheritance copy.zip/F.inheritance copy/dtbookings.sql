Use Myweb; 

DROP TABLE IF EXISTS routes; 
DROP TABLE IF EXISTS bookings; 

CREATE TABLE routes (
  idRoutes INT NOT NULL, 
  deptCity VARCHAR(45) NOT NULL, 
  deptTime VARCHAR(5) NOT NULL, 
  arrivCity VARCHAR(45) NOT NULL, 
  arrivTime VARCHAR(45) NOT NULL, 
  stFare double NOT NULL,
  PRIMARY KEY (idRoutes)); 
  
  DELETE from routes;
  
  INSERT INTO routes VALUES 
  (1000, 'Dundee', '10:00', 'Portsmouth', '12:00', 100.00), 
  (1001, 'Portsmouth', '12:00', 'Dundee', '14:00', 100.00), 
  (1002, 'Bristol', '11:30', 'Manchester', '12:30', 60.00), 
  (1003, 'Manchester', '12:20', 'Bristol', '13:20', 60.00), 
  (1004, 'Bristol', '06:20', 'Manchester', '07:20', 60.00), 
  (1005, 'Manchester', '18:25', 'Bristol', '19:30', 60.00), 
  (1006, 'Bristol', '08:00', 'Newcastle', '09:15', 80.00), 
  (1007, 'Newcastle', '16:45', 'Bristol', '18:00', 80.00), 
  (1008, 'Bristol', '07:40', 'Glasgow', '08:45', 90.00), 
  (1009, 'Bristol', '07:40', 'London', '08:20', 60.00), 
  (1010, 'Southampton', '12:00', 'Manchester', '13:30', 70.00), 
  (1011, 'Manchester', '19:00', 'Southampton', '20:30', 70.00), 
  (1012, 'Cardiff', '06:00', 'Edinburgh', '07:30', 80.00), 
  (1013, 'Edinburgh', '18:30', 'Cardiff', '20:00', 80.00), 
  (1014, 'London', '11:00', 'Manchester', '12:20', 75.00),
  (1015, 'Manchester', '12:20', 'Glasgow', '13:30', 75.00),
  (1016, 'Glasgow', '14:30', 'Newcastle', '15:45', 75.00),
  (1017, 'Newcastle', '16:15', 'Manchester', '17:05', 75.00),
  (1018, 'Birmingham', '16:00', 'Newcastle','17:30', 75.00)
  (1019, 'Newcastle', '06:00', 'Birmingham', '07:30', 75.00)
  (1020, 'Aberdeen', '07:00', 'Portsmouth', '09:00', 75.00);
  
  select * from routes; 
  
  CREATE TABLE bookings (
  idBooking INT NOT NULL auto_increment, 
  deptDate  datetime NOT NULL,   
  arrivDate datetime NOT NULL, 
  idRoutes INT NOT NULL,  
  noOfSeats INT NOT NULL default 1, 
  totFare Double NOT NULL,  
 FOREIGN KEY (idRoutes) REFERENCES routes (idRoutes), 
 PRIMARY KEY (idBooking)
    ); 
    
  select * from bookings; 
  delete from bookings; 