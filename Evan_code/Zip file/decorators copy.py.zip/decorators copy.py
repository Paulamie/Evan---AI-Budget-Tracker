from flask import Flask, render_template

app = Flask (__name__) #instantiating flask app

#home page 
@app.route('/') #decorator/ endpoints
def homePage():
    return render_template('home1.html') #inheritance: base.html

#My account page
@app.route ('/myAccount') #inherirance:base.html
def myAccount():
    return render_template ('account2.html') 

#cookies page 
@app.route ('/cookies') #inheritance: base.html
def Cookies():
    return render_template ('cookies3.html')

#New booking page 
@app.route ('/bookings') #inheritance: secondbase.html
def newBookings():
    return render_template ('NewBookings.html') 

#privacy page 
@app.route ('/privacyStatement') #inheritance: base.html
def privacyPage():
    return render_template ('privacy4.html')

#show prices page 
@app.route ('/prices')#inheritance: secondbase.html
def showPrices():
    return render_template ('showPrices.html') 

#view bookings page 
@app.route ('/viewBookings') #inheritance: secondbase.html
def viewBookings():
    return render_template ('viewBookings.html') 

#debuggers
if __name__ == '__main__':   
   app.run(debug = True)
if __name__ == '__main__':    #you can skip this if running app on terminal window
    for i in range(13000, 18000):
      try:
         app.run(debug = True, port = i)
         break
      except OSError as e:
         print("Port {i} not available".format(i))